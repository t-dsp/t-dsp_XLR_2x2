*PADS-LIBRARY-PART-TYPES-V9*

ECW-FG80475J ECWFG80475J I CAP 7 1 0 0 0
TIMESTAMP 2026.05.07.11.16.28
"Mouser Part Number" 667-ECW-FG80475J
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Panasonic/ECW-FG80475J?qs=W%2FMpXkg%252BdQ4iHPjm7pPZcA%3D%3D
"Manufacturer_Name" Panasonic
"Manufacturer_Part_Number" ECW-FG80475J
"Description" PANASONIC - ECW-FG80475J - CAP, 4.7UF, 800V, FILM, RADIAL
"Datasheet Link" http://industrial.panasonic.com/cdbs/www-data/pdf/RDL0000/RDL0000C245.pdf
"Geometry.Height" 29mm
GATE 1 2 0
ECW-FG80475J
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
13182730/257563/2.50/2/2/Capacitor
